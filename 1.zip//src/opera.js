document.write("<h1>Ejercicio 1</h1>");
//obtener numeros mediante prompt
var x = parseInt(prompt("Ingresa numero 1"));
var y = parseInt(prompt("Ingresa numero 2"));
//realizar procesos
var suma = x + y;
//Mostrar Resultados

document.write("Los numeros ingresados son: " + x + ", " + y);
document.write("<br>");
document.write("la suma de los numeros es: + suma");
//los estudiantes deben relizar las 4 operaciones basicas
